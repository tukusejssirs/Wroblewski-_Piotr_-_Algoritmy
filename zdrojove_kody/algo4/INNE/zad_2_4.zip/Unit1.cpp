//---------------------------------------------------------------------------
#include <vcl.h>
#include <math.h>

#pragma hdrstop

#include "Unit1.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}

//---------------------------------------------------------------------------

void __fastcall TForm1::PaintBox1Paint(TObject *Sender)
{
TRect Rect = PaintBox1->ClientRect;
int Szer, Wysok;
Szer = Rect.Right - Rect.Left;
Wysok = Rect.Bottom - Rect.Top;

//PaintBox1->Canvas->MoveTo(Szer/2,Wysok);

PaintBox1->Canvas->MoveTo(Szer/2,Wysok);


trojkaty(6,Szer/2,Szer/2,Wysok);
}
//---------------------------------------------------------------------------

TForm1::trojkaty(int n, int lg, int x, int y)
{
// n = ilo�� podzia��w
if (n>0)
	{
	int a=lg/n;
	int h=a*sqrt(3)/2;
	PaintBox1->Canvas->LineTo(x-a/2,y-h);
	trojkaty(n-1,lg-a,x-a/2,y-h);
	PaintBox1->Canvas->LineTo(x+a/2,y-h);
	for (double i=1;i<n;i++)
	{
	  PaintBox1->Canvas->LineTo(x+(i-1)*a/2,y-(i+1)*h);
	  PaintBox1->Canvas->LineTo(x+(i+1)*a/2,y-(i+1)*h);
	  }
	PaintBox1->Canvas->LineTo( x,y);
	}
}


